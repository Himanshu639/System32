#include <iostream>
#include <fstream>
#include <stdlib.h>
using namespace std;

int main() 
{
    //system("git clone https://github.com/Himanshu639/Demo.git");
    fstream data;
    data.open("./Demo/data.txt",ios::out);
    
    data<<"bye";
    //system("git remote add origin https://github.com/Himanshu639/Demo.git");
    //system("git push -u origin master");
}